package com.dsr.webclient.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;

import reactor.core.publisher.Flux;

@RestController
public class RestConsumer {

	
	
	@Autowired
	WebClient webClient;

	@Autowired
	private Environment env;

	@GetMapping("/listcars")
	public Flux<Car> getAllCars() {
		
		Flux<Car> cars = webClient
				.get()
				.uri(env.getProperty("cars.url"))
				//.header(HttpHeaders.AUTHORIZATION, Constants.BEARER + getAccessToken())
				.headers(h -> h.setBearerAuth(getAccessToken()))
				.retrieve().bodyToFlux(Car.class);
				// .subscribeOn(System.out::println);

		return cars;
	}

	public String getAccessToken() {
		
		Token token = webClient
				.post()
				.uri(env.getProperty("oauth2.token.url"))
				//.header(HttpHeaders.AUTHORIZATION, Constants.BASIC + env.getProperty("authorization.value"))
				//.headers(h -> h.setBasicAuth(env.getProperty("authorization.value")))
				//.headers(h -> h.setBasicAuth(env.getProperty("appl.client_id"), env.getProperty("appl.secret")))
				.body(BodyInserters.fromFormData("grant_type", "client_credentials")
						.with("client_id", env.getProperty("appl.client_id"))
						.with("client_secret", env.getProperty("appl.secret")))
				.retrieve()
				.bodyToMono(Token.class).block();

		System.out.println("Access token: "  + token.getAccessToken());

		return token.getAccessToken();
	}

//	public String getAccessToken2() {
//		
//		String token = webClient
//				.post()
//				.uri(env.getProperty("oauth2.token.url"))
//				.headers(h -> h.setBasicAuth(env.getProperty("appl.client_id"), env.getProperty("appl.secret")))
//				.body(BodyInserters.fromFormData("grant_type", "password")
//						.with(Constants.USERNAME, env.getProperty("oauth.username"))
//						.with(Constants.PASSWORD, env.getProperty("oauth.password")))
//				.retrieve()
//				.bodyToMono(JsonNode.class)
//				.flatMap(tokenResponse -> {
//			          String accessTokenValue = tokenResponse.get("access_token")
//			            .textValue();
//			          return accessTokenValue;
//			        });
//
//		System.out.println("Access token: "  + token.getAccessToken());
//
//		return token.getAccessToken();
//	}
	
	
	@GetMapping("/posts")
	public String getAllPosts() {
		
		String result = webClient
				.get()
				.uri("https://jsonplaceholder.typicode.com/posts")
				//.header(HttpHeaders.AUTHORIZATION, Constants.BEARER + getAccessToken())
				///.headers(h -> h.setBearerAuth(getAccessToken()))
				.retrieve().bodyToMono(String.class).block();
				// .subscribeOn(System.out::println);

		return result;
	}

}
