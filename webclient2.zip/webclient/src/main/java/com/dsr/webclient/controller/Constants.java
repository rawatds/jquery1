package com.dsr.webclient.controller;

public class Constants {

	final static String BEARER = "Bearer ";
	final static String BASIC = "Basic ";
	final static String USERNAME = "username";
	final static String PASSWORD = "password";
	

}