package com.dsr.webclient;

import java.nio.charset.StandardCharsets;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.client.WebClient;

@SpringBootApplication
public class WebclientApplication {
	
	public static void main(String[] args) {
		SpringApplication.run(WebclientApplication.class, args);
	}

	@Autowired
	private Environment env;
	
	
	@Bean
	public WebClient getWebClient() {
		return WebClient.builder().baseUrl(env.getProperty("base.url"))
				//.accept(MediaType.APPLICATION_JSON)
				//.acceptCharset(StandardCharsets.UTF_8)
				.defaultHeader(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE)
				.build();
	}
	
	
	

}
